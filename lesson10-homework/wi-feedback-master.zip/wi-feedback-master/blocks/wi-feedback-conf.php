<?php

$mail_addr  = 'info@DOMAIN.by';
$mail_topic = 'Поступила заявка с сайта DOMAIN.by';
$mail_from  = 'informer@DOMAIN.by';
$mail_text  = '';

?>